# __init__.py
__version__ = "1.21"

from .cleverdict import CleverDict

