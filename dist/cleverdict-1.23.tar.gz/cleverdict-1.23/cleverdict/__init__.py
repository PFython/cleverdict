# __init__.py
__version__ = "1.23"

from .cleverdict import CleverDict

