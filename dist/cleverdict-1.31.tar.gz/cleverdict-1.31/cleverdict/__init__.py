# __init__.py
__version__ = "1.31"

from .cleverdict import CleverDict

