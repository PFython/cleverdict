# __init__.py
__version__ = "1.4"

from .cleverdict import CleverDict, normalise

