# __init__.py
__version__ = "1.22"

from .cleverdict import CleverDict

