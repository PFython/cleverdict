# __init__.py

from .cleverdict import *
from .cleverdict import __version__
