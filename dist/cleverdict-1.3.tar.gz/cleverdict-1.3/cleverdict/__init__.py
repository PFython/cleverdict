# __init__.py
__version__ = "1.3"

from .cleverdict import CleverDict

